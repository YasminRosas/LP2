﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumericos_Click(object sender, EventArgs e)
        {
            int num = 0;
            for (int i = 0; i < richTextBox1.Text.Length; i++)
            {

                if (Char.IsNumber(Convert.ToChar(richTextBox1.Text.Substring(i, 1))))
                {
                    num++;
                }
            }
            MessageBox.Show(string.Format("No texto há {0} números", num));
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            int s = 0;
            while (i < richTextBox1.Text.Length)
            {
                if (Char.IsWhiteSpace(richTextBox1.Text[i]))
                {
                    s = i + 1;
                    break;
                }
                i++;
            }
            if (s == 0)
            {
                MessageBox.Show("Não há espaço em branco");
            }
            else
            {
                MessageBox.Show(string.Format("O espaço em branco está na posição {0} ", s));
            }
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int letras = 0;
            foreach (char l in richTextBox1.Text)
            {
                if (Char.IsLetter(l))
                    letras++;
            }
            MessageBox.Show(string.Format("No texto há {0} letras", letras));
        }
    }
}
