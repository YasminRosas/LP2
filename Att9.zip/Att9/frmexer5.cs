﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Att9
{
    public partial class frmexer5 : Form
    {
        public frmexer5()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            string nota;
            string resultado = "";

            for (int i = 0; i < 20; i++)
            {
                media[i] = 0;

                for (int j = 0; j < 3; j++)
                {
                    while (true)
                    {
                 nota = Interaction.InputBox("Aluno: " + (i + 1) + "\nDisciplina: " + (j + 1));

                if (double.TryParse(nota, out notas[i, j]))
                {
                 media[i] += notas[i, j];
                 break;
                }

                 else
                   MessageBox.Show("Entrada inválida!");
                    }
                }
            }

            for (int i = 0; i < 20; i++)
                resultado += "Aluno " + (i + 1) + ": média: " + (media[i] / 3).ToString("N2") + "\n";

            MessageBox.Show(resultado);
        }
    }
}
