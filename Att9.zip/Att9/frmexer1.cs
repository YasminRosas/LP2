﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Att9
{
    public partial class frmexer1 : Form
    {
        public frmexer1()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            string inverte = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Digite um número, posição:" + (i + 1),
                    "Entrada de Dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("número inválido");
                    i--;
                }
                else
                    inverte = vetor[i] + "\n" + inverte;
            }

            MessageBox.Show(inverte);
        }
    }
}
