﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Att9
{
    public partial class frmexer6 : Form
    {
        public frmexer6()
        {
            InitializeComponent();
        }

        private void btnIniciaar_Click(object sender, EventArgs e)
        {
            string[] nome = new string[8];
            string aux, branco;
            int[] pessoas = new int[8];
            int total;

            for (int j = 0; j < nome.Length; j++)
            {
                aux = Interaction.InputBox("Digite o " + (j + 1) + "° nome: ", "Entrada de Dados");
                nome[j] = aux;
                branco = aux.Replace(" ", string.Empty);
                total = branco.Length;
                pessoas[j] = total;
            }

            for (int j = 0; j < 8; j++)
                ltbValores.Items.Add("O nome inserido " + nome[j] + " tem " + pessoas[j] + " caracteres");
        }
    }
}
