﻿
namespace Att9
{
    partial class frmexer3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTotal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTotal
            // 
            this.btnTotal.BackColor = System.Drawing.Color.Thistle;
            this.btnTotal.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F);
            this.btnTotal.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnTotal.Location = new System.Drawing.Point(147, 108);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(151, 107);
            this.btnTotal.TabIndex = 1;
            this.btnTotal.Text = "Total";
            this.btnTotal.UseVisualStyleBackColor = false;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // frmexer3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Att9.Properties.Resources.att9nuvem;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(438, 311);
            this.Controls.Add(this.btnTotal);
            this.Name = "frmexer3";
            this.Text = "frmexer3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTotal;
    }
}