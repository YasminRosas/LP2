﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Att9
{
    public partial class frmexer4 : Form
    {
        public frmexer4()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList(10);

            for (int i = 0; i < 10; i++)
            {
                alunos.Add("Ana");
                alunos.Add("André");
                alunos.Add("Débora");
                alunos.Add("Fátima");
                alunos.Add("João");
                alunos.Add("Janete");
                alunos.Add("Otávio");
                alunos.Add("Marcelo");
                alunos.Add("Pedro");
                alunos.Add("Thais");
            }

            MessageBox.Show("Lista dos alunos \n\n" + String.Join("\n", alunos));

            alunos.Remove("Otávio");

            string alunosalterado = "";

            for (int i = 0; i < 9; i++)
                alunosalterado += alunos[i] + " ";

            MessageBox.Show("Lista dos alunos alterada \n\n" + String.Join("\n", alunosalterado));
        }
    }
}
