﻿
namespace Att9
{
    partial class frmexer6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIniciaar = new System.Windows.Forms.Button();
            this.ltbValores = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnIniciaar
            // 
            this.btnIniciaar.BackColor = System.Drawing.Color.White;
            this.btnIniciaar.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F);
            this.btnIniciaar.ForeColor = System.Drawing.Color.HotPink;
            this.btnIniciaar.Location = new System.Drawing.Point(24, 126);
            this.btnIniciaar.Name = "btnIniciaar";
            this.btnIniciaar.Size = new System.Drawing.Size(194, 95);
            this.btnIniciaar.TabIndex = 0;
            this.btnIniciaar.Text = "Iniciar";
            this.btnIniciaar.UseVisualStyleBackColor = false;
            this.btnIniciaar.Click += new System.EventHandler(this.btnIniciaar_Click);
            // 
            // ltbValores
            // 
            this.ltbValores.FormattingEnabled = true;
            this.ltbValores.Location = new System.Drawing.Point(235, 27);
            this.ltbValores.Name = "ltbValores";
            this.ltbValores.Size = new System.Drawing.Size(207, 303);
            this.ltbValores.TabIndex = 1;
            // 
            // frmexer6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Att9.Properties.Resources.att9minnie;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(470, 364);
            this.Controls.Add(this.ltbValores);
            this.Controls.Add(this.btnIniciaar);
            this.Name = "frmexer6";
            this.Text = "frmexer6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnIniciaar;
        private System.Windows.Forms.ListBox ltbValores;
    }
}