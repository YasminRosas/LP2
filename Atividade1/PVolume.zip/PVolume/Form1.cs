﻿using System;
using System.Windows.Forms;

namespace PVolume
{
    public partial class frmCal : Form
    {
        
        Double raio;
        Double altura;
        public static string nome;
        public frmCal()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtAltura.Text, out altura) && Double.TryParse(txtRaio.Text, out raio))
            {
                double volume;
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }

            else
            {
                MessageBox.Show("Valores Inválidos");
                txtRaio.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;

            txtRaio.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if ((txtRaio.Text == "") && (txtAltura.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtRaio.Text, out raio))
                {
                    MessageBox.Show("Valor de raio é inválido!");
                    txtRaio.Text = "";
                    txtRaio.Focus();
                }
                else if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Text = "";
                    txtRaio.Focus();
                }
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((txtRaio.Text == "") && (txtAltura.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtAltura.Text, out altura))
                {
                    MessageBox.Show("Valor de altura é inválido!");
                    txtAltura.Text = "";
                    txtAltura.Focus();
                }
                else if (raio <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    txtAltura.Text = "";
                    txtAltura.Focus();
                }
            }
        }
        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtVolume_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
