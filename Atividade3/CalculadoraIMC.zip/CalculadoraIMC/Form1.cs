﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraIMC
{
    public partial class frmcalculadora : Form
    {

        double altura;
       
        public frmcalculadora()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();

            txtAltura.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc;
            double altura;
            double peso;

            if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtPeso.Text, out peso))
            {

                if ((altura <= 0) || (peso <= 0))
                    MessageBox.Show("Valor deve ser maior que zero!");
                else
                {
                    imc = peso / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1);

                    txtIMC.Text = imc.ToString("N1");

                    if (imc < 18.5) MessageBox.Show("Magreza");
                    else if (imc <= 24.9) MessageBox.Show("Normal");
                    else if (imc <= 29.9) MessageBox.Show("Sobrepeso");
                    else if (imc <= 39.9) MessageBox.Show("Obesidade");
                    else MessageBox.Show("Obesidade grave");
                }
            }
            else MessageBox.Show("Valores inválidos!");
            
        }

        private void validated_Altura(object sender, EventArgs e)
        {
            if ((txtAltura.Text == "") && (txtPeso.Text == ""))
                this.Close();
            else if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Valor é inválido!");
                txtPeso.Focus();
                this.Close();
            }
        }

        private void validated_Peso(object sender, EventArgs e)
        {
            if ((txtAltura.Text == "") && (txtPeso.Text == ""))
                this.Close();
            else if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Valor é inválido!");
                txtPeso.Focus();
                this.Close();
            }
        }
    }
}
