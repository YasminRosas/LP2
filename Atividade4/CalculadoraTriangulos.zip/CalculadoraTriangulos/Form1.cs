﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraTriangulos
{
    public partial class frmCalculadoraABC : Form
    {
        public frmCalculadoraABC()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double A, B, C;

            if (!double.TryParse(txtA.Text, out A) || 
                !double.TryParse(txtB.Text, out B) || 
                !double.TryParse(txtC.Text, out C))
            {
                MessageBox.Show("Valores devem ser Numéricos");
            }

            else if ((txtA.Text == "0") ||
                (txtB.Text == "0") ||
                (txtC.Text == "0"))
            {
                MessageBox.Show("Não é possivel formar um triângulo com valor nulo!!!");
            }


            else
            {
                if ( A < (B + C) 
                    && A > Math.Abs(B - C) 
                    && B < (A + C) 
                    && B >  Math.Abs(A - C) 
                    && C < (A + B) 
                    && C > Math.Abs(A - B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("O triângulo é equilátero!");
                    }
                    else
                    {
                        if (A == B || A == C || C == B)
                        {
                            MessageBox.Show("O triângulo é isósceles!");
                        }
                        else
                        {
                            MessageBox.Show("O triângulo é escaleno!");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Impossivel formar um triângulo!!");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();

            txtA.Focus();
        }
    }
}
