﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482111018
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            lboxTotal.Items.Clear();

            int M = 8, S = 4;

            double[,] m = new double[M, S];
            double[] Mes = new double[M];
            double Total = 0;

            string auxiliar = "";

            for (int i = 0; i < M ; i++)
            {

                double soma = 0;

                lboxTotal.Items.Add("------------------------------------");
                lboxTotal.Items.Add(" ");

                for (int j = 0; j < S; j++)
                {
                    auxiliar = Interaction.InputBox(" Total da Semana: " + (j + 1).ToString() +
                        "\n Total do Mês: " + (i + 1).ToString());

                if (double.TryParse(auxiliar, out m[i, j]))
                {

                  m[i, j] = Convert.ToDouble(auxiliar);
                  Total = Total + m[i, j];
                  soma = soma + m[i, j];

                    
                     lboxTotal.Items.Add(" Total do mês: " + (i + 1).ToString() + " \nSemana: " +
                         (j + 1) + (" ") + (String.Format("{0:C2}", m[i, j])));

                }
                else
                {
                  MessageBox.Show("Dado não é válido!");
                  j--;
                }


                }

             Mes[i] = soma;

             lboxTotal.Items.Add(" ");
             lboxTotal.Items.Add(" >> Total Mês:" + (String.Format("{0:C2}", Mes[i])));
             lboxTotal.Items.Add(" ");

            }

            lboxTotal.Items.Add("------------------------------------");
            lboxTotal.Items.Add(" ");
            lboxTotal.Items.Add(" >> Total Geral: " + (String.Format("{0:C2}", Total)));
            lblTotal.Text = " >> Total Geral: " + (String.Format("{0:C2}", Total));
        }
    }
}
