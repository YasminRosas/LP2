﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Att8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double gratificacao, salario;
            
            int producao;

            if ((double.TryParse(txtSalario.Text, out salario)) && (double.TryParse(txtGratificacao.Text, out gratificacao)) &&
                int.TryParse(txtProducao.Text, out producao))
            {
                int B = 0, C = 0, D = 0;
                double salarioBruto;

                if (producao >= 100)
                {
                    B = 1;
                    if (producao >= 120)
                    {
                        C = 1;
                        if (producao >= 150)
                            D = 1;
                    }
                }

                salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

                if (salarioBruto > 7000)
                {
                    if (producao >= 150 && gratificacao > 0)
                        MessageBox.Show(( 
                            "Funcionário: " + txtNome.Text +".\n" +
                            "Cargo: " + txtCargo.Text + ".\n" +
                            "O salário bruto é R$: " + salarioBruto.ToString("N2") + "."));

                    else
                        MessageBox.Show(
                            "Funcionário" + txtNome.Text + "." +
                            "Cargo: " + txtCargo.Text + ".\n" +
                            "O salário bruto é R$ 7000,00");
                }

                else
                    MessageBox.Show((
                        "Funcionário" + txtNome.Text + "." +
                        "Cargo: " + txtCargo.Text + ".\n" +
                        "O salário bruto é: R$ " + salarioBruto.ToString("N2") + "."));
            }

            else
                MessageBox.Show("O valor é inválido.");
        }
    }
}
