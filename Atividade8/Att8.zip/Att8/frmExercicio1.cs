﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Att8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaço_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int espaco = 0;
                
                while (cont < richTextBox1.Text.Length)
            {
                if (char.IsWhiteSpace(richTextBox1.Text[cont]))
                {
                    espaco++;
                }
                cont++;
            }

            MessageBox.Show("Na frase há " + espaco + " espaço em branco!");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int letrar = 0;

                foreach (char c in richTextBox1.Text)
            {
                if (c == 'R' || c == 'r')
                    letrar++;
            }
            MessageBox.Show("Tem " + letrar + " letras 'R' ");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int i;
            int par = 0;

            for (i = 1; i < richTextBox1.Text.Length; i++)
            {
                if (richTextBox1.Text[i] == richTextBox1.Text[i - 1])
                {
                    par++;
                }
            }
            MessageBox.Show("Aparece par de letras " + par + " vezes no texto");
        }
    }
}
