﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Att8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
           txtPalavra1.Text = txtPalavra1.Text.ToUpper(); 

           txtPalavra1.Text = txtPalavra1.Text.Replace(" ", ""); 

           string inverter = txtPalavra1.Text;
           char[] aux = inverter.ToCharArray();
           Array.Reverse(aux);
           inverter = "";
           foreach (char c in aux)
           inverter += c.ToString();

        txtPalavra2.Text = inverter;

          if (String.Compare(txtPalavra1.Text, inverter) == 0) 
            {
                MessageBox.Show("É um palíndromo.");
            }
          else
            {
                MessageBox.Show("Não é um palíndromo.");
            }
        }
    }
}
