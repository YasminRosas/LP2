﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Att8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            int N;
            if ((txtNumeroN.Text == string.Empty) || (!int.TryParse(txtNumeroN.Text, out N)))
            {
               MessageBox.Show("Valor inválido");
               txtNumeroN.Clear();
               rtbNumeroH.Clear();
            }

            else
            {
                int i;
                double H = 0;
                N = int.Parse(txtNumeroN.Text);

            for (i = 1; i <= N; i++)
            {
               H += 1 / (double)i;
            }
              rtbNumeroH.Text = "O valor de H é " + H.ToString("N4") + ".";
            }
        }
    }
}
