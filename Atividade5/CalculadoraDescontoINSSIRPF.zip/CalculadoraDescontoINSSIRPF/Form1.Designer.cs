﻿
namespace CalculadoraDescontoINSSIRPF
{
    partial class frmDesconto
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblnome = new System.Windows.Forms.Label();
            this.txtFuncionario = new System.Windows.Forms.TextBox();
            this.comboboxFilhos = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radbtnM = new System.Windows.Forms.RadioButton();
            this.radbtnF = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkCasado = new System.Windows.Forms.CheckBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.lblsalario = new System.Windows.Forms.Label();
            this.lblfilhos = new System.Windows.Forms.Label();
            this.lblinss = new System.Windows.Forms.Label();
            this.lblirpf = new System.Windows.Forms.Label();
            this.lblfamilia = new System.Windows.Forms.Label();
            this.lblliquido = new System.Windows.Forms.Label();
            this.lbldescontoinss = new System.Windows.Forms.Label();
            this.lbldescontoirpf = new System.Windows.Forms.Label();
            this.txtINSS = new System.Windows.Forms.TextBox();
            this.txtIRPF = new System.Windows.Forms.TextBox();
            this.txtFamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioliquido = new System.Windows.Forms.TextBox();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtDescontoIRPF = new System.Windows.Forms.TextBox();
            this.lbltitulo = new System.Windows.Forms.Label();
            this.lblseparador = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnVerificar
            // 
            this.btnVerificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnVerificar.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.ForeColor = System.Drawing.Color.White;
            this.btnVerificar.Location = new System.Drawing.Point(313, 384);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(192, 39);
            this.btnVerificar.TabIndex = 0;
            this.btnVerificar.Text = "VERIFICAR DESCONTOS";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblnome.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnome.ForeColor = System.Drawing.Color.White;
            this.lblnome.Location = new System.Drawing.Point(9, 69);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(185, 20);
            this.lblnome.TabIndex = 1;
            this.lblnome.Text = "NOME DO FUNCIONÁRIO";
            // 
            // txtFuncionario
            // 
            this.txtFuncionario.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFuncionario.Location = new System.Drawing.Point(199, 62);
            this.txtFuncionario.Name = "txtFuncionario";
            this.txtFuncionario.Size = new System.Drawing.Size(192, 27);
            this.txtFuncionario.TabIndex = 2;
            this.txtFuncionario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFuncionario_KeyPress);
            this.txtFuncionario.Validated += new System.EventHandler(this.txtFuncionario_Validated);
            // 
            // comboboxFilhos
            // 
            this.comboboxFilhos.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboboxFilhos.FormattingEnabled = true;
            this.comboboxFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboboxFilhos.Location = new System.Drawing.Point(199, 147);
            this.comboboxFilhos.Name = "comboboxFilhos";
            this.comboboxFilhos.Size = new System.Drawing.Size(192, 28);
            this.comboboxFilhos.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.radbtnM);
            this.groupBox1.Controls.Add(this.radbtnF);
            this.groupBox1.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(448, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(85, 86);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SEXO";
            // 
            // radbtnM
            // 
            this.radbtnM.AutoSize = true;
            this.radbtnM.Location = new System.Drawing.Point(22, 53);
            this.radbtnM.Name = "radbtnM";
            this.radbtnM.Size = new System.Drawing.Size(41, 24);
            this.radbtnM.TabIndex = 1;
            this.radbtnM.TabStop = true;
            this.radbtnM.Text = "M";
            this.radbtnM.UseVisualStyleBackColor = true;
            // 
            // radbtnF
            // 
            this.radbtnF.AutoSize = true;
            this.radbtnF.Location = new System.Drawing.Point(22, 30);
            this.radbtnF.Name = "radbtnF";
            this.radbtnF.Size = new System.Drawing.Size(35, 24);
            this.radbtnF.TabIndex = 0;
            this.radbtnF.TabStop = true;
            this.radbtnF.Text = "F";
            this.radbtnF.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.checkCasado);
            this.panel1.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(448, 137);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(143, 37);
            this.panel1.TabIndex = 5;
            // 
            // checkCasado
            // 
            this.checkCasado.AutoSize = true;
            this.checkCasado.BackColor = System.Drawing.Color.Transparent;
            this.checkCasado.ForeColor = System.Drawing.Color.White;
            this.checkCasado.Location = new System.Drawing.Point(22, 10);
            this.checkCasado.Name = "checkCasado";
            this.checkCasado.Size = new System.Drawing.Size(107, 24);
            this.checkCasado.TabIndex = 0;
            this.checkCasado.Text = "CASADO(A)";
            this.checkCasado.UseVisualStyleBackColor = false;
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioBruto.Location = new System.Drawing.Point(199, 106);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(192, 27);
            this.txtSalarioBruto.TabIndex = 6;
            // 
            // lblsalario
            // 
            this.lblsalario.AutoSize = true;
            this.lblsalario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblsalario.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalario.ForeColor = System.Drawing.Color.White;
            this.lblsalario.Location = new System.Drawing.Point(74, 113);
            this.lblsalario.Name = "lblsalario";
            this.lblsalario.Size = new System.Drawing.Size(120, 20);
            this.lblsalario.TabIndex = 7;
            this.lblsalario.Text = "SALÁRIO BRUTO";
            // 
            // lblfilhos
            // 
            this.lblfilhos.AutoSize = true;
            this.lblfilhos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblfilhos.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfilhos.ForeColor = System.Drawing.Color.White;
            this.lblfilhos.Location = new System.Drawing.Point(44, 155);
            this.lblfilhos.Name = "lblfilhos";
            this.lblfilhos.Size = new System.Drawing.Size(150, 20);
            this.lblfilhos.TabIndex = 8;
            this.lblfilhos.Text = "NÚMERO DE FILHOS";
            // 
            // lblinss
            // 
            this.lblinss.AutoSize = true;
            this.lblinss.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblinss.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinss.ForeColor = System.Drawing.Color.White;
            this.lblinss.Location = new System.Drawing.Point(22, 281);
            this.lblinss.Name = "lblinss";
            this.lblinss.Size = new System.Drawing.Size(116, 20);
            this.lblinss.TabIndex = 11;
            this.lblinss.Text = "ALÍQUOTA INSS";
            // 
            // lblirpf
            // 
            this.lblirpf.AutoSize = true;
            this.lblirpf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblirpf.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblirpf.ForeColor = System.Drawing.Color.White;
            this.lblirpf.Location = new System.Drawing.Point(23, 322);
            this.lblirpf.Name = "lblirpf";
            this.lblirpf.Size = new System.Drawing.Size(114, 20);
            this.lblirpf.TabIndex = 10;
            this.lblirpf.Text = "ALÍQUOTA IRPF";
            // 
            // lblfamilia
            // 
            this.lblfamilia.AutoSize = true;
            this.lblfamilia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblfamilia.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfamilia.ForeColor = System.Drawing.Color.White;
            this.lblfamilia.Location = new System.Drawing.Point(6, 359);
            this.lblfamilia.Name = "lblfamilia";
            this.lblfamilia.Size = new System.Drawing.Size(128, 20);
            this.lblfamilia.TabIndex = 9;
            this.lblfamilia.Text = "SALÁRIO FAMÍLIA";
            // 
            // lblliquido
            // 
            this.lblliquido.AutoSize = true;
            this.lblliquido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblliquido.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblliquido.ForeColor = System.Drawing.Color.White;
            this.lblliquido.Location = new System.Drawing.Point(7, 398);
            this.lblliquido.Name = "lblliquido";
            this.lblliquido.Size = new System.Drawing.Size(131, 20);
            this.lblliquido.TabIndex = 12;
            this.lblliquido.Text = "SALÁRIO LIQUÍDO";
            // 
            // lbldescontoinss
            // 
            this.lbldescontoinss.AutoSize = true;
            this.lbldescontoinss.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lbldescontoinss.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescontoinss.ForeColor = System.Drawing.Color.White;
            this.lbldescontoinss.Location = new System.Drawing.Point(326, 300);
            this.lbldescontoinss.Name = "lbldescontoinss";
            this.lbldescontoinss.Size = new System.Drawing.Size(123, 20);
            this.lbldescontoinss.TabIndex = 13;
            this.lbldescontoinss.Text = "DESCONTO INSS";
            // 
            // lbldescontoirpf
            // 
            this.lbldescontoirpf.AutoSize = true;
            this.lbldescontoirpf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lbldescontoirpf.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescontoirpf.ForeColor = System.Drawing.Color.White;
            this.lbldescontoirpf.Location = new System.Drawing.Point(326, 341);
            this.lbldescontoirpf.Name = "lbldescontoirpf";
            this.lbldescontoirpf.Size = new System.Drawing.Size(121, 20);
            this.lbldescontoirpf.TabIndex = 14;
            this.lbldescontoirpf.Text = "DESCONTO IRPF";
            // 
            // txtINSS
            // 
            this.txtINSS.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtINSS.Location = new System.Drawing.Point(150, 278);
            this.txtINSS.Name = "txtINSS";
            this.txtINSS.ReadOnly = true;
            this.txtINSS.Size = new System.Drawing.Size(134, 27);
            this.txtINSS.TabIndex = 15;
            // 
            // txtIRPF
            // 
            this.txtIRPF.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIRPF.Location = new System.Drawing.Point(150, 319);
            this.txtIRPF.Name = "txtIRPF";
            this.txtIRPF.ReadOnly = true;
            this.txtIRPF.Size = new System.Drawing.Size(134, 27);
            this.txtIRPF.TabIndex = 16;
            // 
            // txtFamilia
            // 
            this.txtFamilia.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFamilia.Location = new System.Drawing.Point(150, 356);
            this.txtFamilia.Name = "txtFamilia";
            this.txtFamilia.ReadOnly = true;
            this.txtFamilia.Size = new System.Drawing.Size(134, 27);
            this.txtFamilia.TabIndex = 17;
            // 
            // txtSalarioliquido
            // 
            this.txtSalarioliquido.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioliquido.Location = new System.Drawing.Point(150, 395);
            this.txtSalarioliquido.Name = "txtSalarioliquido";
            this.txtSalarioliquido.ReadOnly = true;
            this.txtSalarioliquido.Size = new System.Drawing.Size(134, 27);
            this.txtSalarioliquido.TabIndex = 18;
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescontoINSS.Location = new System.Drawing.Point(458, 297);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.ReadOnly = true;
            this.txtDescontoINSS.Size = new System.Drawing.Size(133, 27);
            this.txtDescontoINSS.TabIndex = 19;
            // 
            // txtDescontoIRPF
            // 
            this.txtDescontoIRPF.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescontoIRPF.Location = new System.Drawing.Point(458, 338);
            this.txtDescontoIRPF.Name = "txtDescontoIRPF";
            this.txtDescontoIRPF.ReadOnly = true;
            this.txtDescontoIRPF.Size = new System.Drawing.Size(133, 27);
            this.txtDescontoIRPF.TabIndex = 20;
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.BackColor = System.Drawing.Color.Transparent;
            this.lbltitulo.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitulo.ForeColor = System.Drawing.Color.White;
            this.lbltitulo.Location = new System.Drawing.Point(203, 23);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(226, 25);
            this.lbltitulo.TabIndex = 21;
            this.lbltitulo.Text = "DESCONTOS INSS E IRPF";
            // 
            // lblseparador
            // 
            this.lblseparador.AutoSize = true;
            this.lblseparador.BackColor = System.Drawing.Color.Transparent;
            this.lblseparador.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblseparador.ForeColor = System.Drawing.Color.Gold;
            this.lblseparador.Location = new System.Drawing.Point(22, 255);
            this.lblseparador.Name = "lblseparador";
            this.lblseparador.Size = new System.Drawing.Size(585, 20);
            this.lblseparador.TabIndex = 22;
            this.lblseparador.Text = "_________________________________________________________________________________" +
    "_______________";
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSair.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSair.Location = new System.Drawing.Point(527, 395);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(84, 28);
            this.btnSair.TabIndex = 23;
            this.btnSair.Text = "&SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblMensagem.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblMensagem.ForeColor = System.Drawing.Color.White;
            this.lblMensagem.Location = new System.Drawing.Point(12, 190);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(0, 20);
            this.lblMensagem.TabIndex = 24;
            // 
            // frmDesconto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CalculadoraDescontoINSSIRPF.Properties.Resources.passage_wallpaper;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(623, 435);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblseparador);
            this.Controls.Add(this.lbltitulo);
            this.Controls.Add(this.txtDescontoIRPF);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.txtSalarioliquido);
            this.Controls.Add(this.txtFamilia);
            this.Controls.Add(this.txtIRPF);
            this.Controls.Add(this.txtINSS);
            this.Controls.Add(this.lbldescontoirpf);
            this.Controls.Add(this.lbldescontoinss);
            this.Controls.Add(this.lblliquido);
            this.Controls.Add(this.lblinss);
            this.Controls.Add(this.lblirpf);
            this.Controls.Add(this.lblfamilia);
            this.Controls.Add(this.lblfilhos);
            this.Controls.Add(this.lblsalario);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.comboboxFilhos);
            this.Controls.Add(this.txtFuncionario);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.btnVerificar);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmDesconto";
            this.Text = "Calculadora Desconto INSS e IRPF";
            this.Load += new System.EventHandler(this.frmDesconto_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.TextBox txtFuncionario;
        private System.Windows.Forms.ComboBox comboboxFilhos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radbtnM;
        private System.Windows.Forms.RadioButton radbtnF;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkCasado;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.Label lblsalario;
        private System.Windows.Forms.Label lblfilhos;
        private System.Windows.Forms.Label lblinss;
        private System.Windows.Forms.Label lblirpf;
        private System.Windows.Forms.Label lblfamilia;
        private System.Windows.Forms.Label lblliquido;
        private System.Windows.Forms.Label lbldescontoinss;
        private System.Windows.Forms.Label lbldescontoirpf;
        private System.Windows.Forms.TextBox txtINSS;
        private System.Windows.Forms.TextBox txtIRPF;
        private System.Windows.Forms.TextBox txtFamilia;
        private System.Windows.Forms.TextBox txtSalarioliquido;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.TextBox txtDescontoIRPF;
        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Label lblseparador;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblMensagem;
    }
}

