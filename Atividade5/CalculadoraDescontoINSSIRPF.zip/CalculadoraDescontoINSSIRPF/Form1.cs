﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraDescontoINSSIRPF
{
    public partial class frmDesconto : Form
    {
        public frmDesconto()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIR = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;

            if ((txtFuncionario.Text == "") || (txtFuncionario.Text.Length < 5))
                MessageBox.Show("Nome inválido");
            else if (double.TryParse(txtSalarioBruto.Text, out salarioBruto))
            {
                if (salarioBruto <= 0)
                    MessageBox.Show("Salário Bruto Inválido!");
                else
                {
                    // Calculo do INSS
                    if (salarioBruto <= 800.47)
                    {
                        txtINSS.Text = "7.65%";
                        descontoINSS = 0.0765 * salarioBruto;
                    }

                    else if (salarioBruto <= 1050)
                    {
                        txtINSS.Text = "8.65%";
                        descontoINSS = 0.0865 * salarioBruto;
                    }

                    else if (salarioBruto <= 1400.77)
                    {
                        txtINSS.Text = "9%";
                        descontoINSS = 0.09 * salarioBruto;
                    }
                   
                    else if (salarioBruto <= 2801.56)
                    {
                        txtINSS.Text = "11%";
                        descontoINSS = 0.11 * salarioBruto;
                    }
                    else 
                    {
                        txtINSS.Text = "11%";
                        descontoINSS = 308.17;
                    }

                    // Mostra o desconto do INSS
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    // Calculo IRPF

                    if (salarioBruto <= 1257.12)
                    {
                        txtIRPF.Text = "Isento";
                        descontoIR = 0;
                    }

                    else if (salarioBruto <= 2512.08)
                    {
                        txtIRPF.Text = "15%";
                        descontoIR = 0.15 * salarioBruto;
                    }

                    else
                    {
                        txtIRPF.Text = "27.5%";
                        descontoIR = 0.275 * salarioBruto;
                    }

                    txtDescontoIRPF.Text = descontoIR.ToString("N2");

                    // Calculo Salário Familia

                    if (salarioBruto <= 435.52)
                    {
                        salarioFamilia = 22.33 * Convert.ToDouble(comboboxFilhos.SelectedItem);
                        txtFamilia.Text = salarioFamilia.ToString("N2");
                    }

                    else if (salarioBruto <= 654.61)
                    {
                        salarioFamilia = 15.74 * Convert.ToDouble(comboboxFilhos.SelectedItem);
                        txtFamilia.Text = salarioFamilia.ToString("N2");
                    }

                    else
                    {
                        salarioFamilia = 0;
                        txtFamilia.Text = salarioFamilia.ToString("N2");
                    }

                    // salário liquido

                    salarioLiquido = salarioBruto - descontoINSS - descontoIR + salarioFamilia;

                    txtSalarioliquido.Text = salarioLiquido.ToString("N2");

                    // Menssagem no label

                    lblMensagem.Visible = true;

                    lblMensagem.Text = "Os descontos do salário";

                    if (radbtnF.Checked)
                        lblMensagem.Text = lblMensagem.Text + " da Sra " + txtFuncionario.Text + ".";
                    else
                        lblMensagem.Text = lblMensagem.Text + " do Sr " + txtFuncionario.Text + ".";

                    lblMensagem.Text = lblMensagem.Text + "\nEstado civil: ";

                    if (checkCasado.Checked)
                        lblMensagem.Text = lblMensagem.Text + " casado(a). ";
                    else
                        lblMensagem.Text = lblMensagem.Text + " solteiro(a). ";

                    lblMensagem.Text = lblMensagem.Text + "\nE que tem " + comboboxFilhos.SelectedItem.ToString() + " filho(s) são: ";

                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtFuncionario_Validated(object sender, EventArgs e)
        {
            if ((txtFuncionario.Text == "") || (txtFuncionario.Text.Length < 5))
                MessageBox.Show("Nome inválido");
               // txtFuncionario.Focus();
        }

        private void txtFuncionario_KeyPress(object sender, KeyPressEventArgs e)
        {
           /* if (!Char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Só é aceito letras");
                e.KeyChar = '\0';
            }*/
        }

        private void frmDesconto_Load(object sender, EventArgs e)
        {
            comboboxFilhos.SelectedIndex = 0;
        }
    }
}
